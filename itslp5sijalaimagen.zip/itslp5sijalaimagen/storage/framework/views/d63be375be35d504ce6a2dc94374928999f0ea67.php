<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Documentos del Aspirante...</div>

                <div class="panel-body">
                <h2>Agregar documentos</h2>
                    <form>
                      <label>Seleccione archivo:</label>

                     <table border="1">
                         <tr><th>Descripción</th><th>Ruta/Nombre del ArchivoEdad</th><th>Actualizar</th><th>Eliminar</th></tr>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>