<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Datos de los Aspirantes...</div>

                <div class="panel-body">
                    <form>
                      <label>Seleccione carrera:</label>
                    <select>

                        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($carrera->num_carrera_int); ?>"><?php echo e($carrera->nom_corto_tx); ?>- <?php echo e($carrera->nom_largo_tx); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>


                     <h1>Alumnos</h1>
                     <table border="1">
                         <tr><th>Nombre</th><th>Edad</th><th>Curp</th><th>Curp</th></tr>
                        <?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <tr><td><?php echo e($candidato-> name); ?></td><td><?php echo e($candidato->edad); ?></td><td><?php echo e($candidato->curp); ?></td><td>
                                <a href="<?php echo e(URL::route('candidatoDocumento')); ?>">Documentos</a>
                                </td></td></td</td></tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>