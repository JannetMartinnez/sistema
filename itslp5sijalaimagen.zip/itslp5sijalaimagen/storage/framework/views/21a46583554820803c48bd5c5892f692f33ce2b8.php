<?php $__env->startSection('pageTitle', 'Aspirantes'); ?>

<?php $__env->startSection('content'); ?>
<div class="container principal">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Datos de los Aspirantes...</div>

                <div class="panel-body">
                    <form>
                      <label class="col-xs-12 col-sm-2 col-md-2 col-lg-2 control-label" for="carrera">&nbsp;Seleccione carrera:</label>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 ">
                    <select id="carrera">
                        <?php $__currentLoopData = $carreras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $carrera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($carrera->num_carrera_int); ?>"><?php echo e($carrera->nom_corto_tx); ?>- <?php echo e($carrera->nom_largo_tx); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </select>
                    </div>
                  </div>
                     <div class="table-responsive">
                       <table class="table table-bordered table-striped">
                        <thead>
                          <tr>
                            <th>Nombre</th>
                            <th>Edad</th>
                            <th>Curp</th>
                            <th>Documentos</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td><?php echo e($candidato-> name); ?></td>
                              <td class="text-center"><?php echo e($candidato->edad); ?></td>
                              <td><?php echo e($candidato->curp); ?></td>
                              <td class="text-center">
                                <a href="<?php echo e(URL::route('candidatoDocumento')); ?>"><i class="fa fa-cloud-upload" aria-hidden="true"></i> Documentos</a>
                              </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>