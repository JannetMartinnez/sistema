<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <h1>imagen del documento Acta de Nacimiento</h1>
 <img src="<?php echo e(asset('storage/estsela.jpg')); ?>">
</body>
</html>