<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/candidato', 'CandidatoController@index');

Route::get('/candidatoDocumento', 'CandidatoDocumentoController@index')->name('candidatoDocumento');


	


Route::post('candidatoDocumento/create', 'CandidatoDocumentoController@store')->name('uno');

Route::get('/candidatoDocumento/show', 'CandidatoDocumentoController@show')->name('dos');
Route::get('/candidatoDocumento/destroy', 'CandidatoDocumentoController@destroy')->name('tres');