<?php

$path = "C:\Bitnami\wappstack-7.0.23-0\apache2\htdocs\7Dic14_56\periodos_escolares.txt";

if (!file_exists($path))
    exit("File not found");

$file = fopen($path, "r");



if ($file) {
        
	$cadena="DB::Table('periodos_escolares')->insert([";		

    while (($line = fgets($file)) !== false) {


        $array=explode (',', $line);
        $cadena=$cadena."['periodo'=>'".trim($array[1])."','identificacion_larga'=>'".trim($array[2])."','identificacion_corta'=>154,'fecha_inicio'=>".trim($array[0])."],</br>";


    }
    $cadena=$cadena."]);";
    echo $cadena;
    if (!feof($file)) {
        echo "Error: EOF not found\n";
    }
    fclose($file);
}

?>