<?php

use Illuminate\Database\Seeder;
use Tecnologico\Candidato;

class TablaCandidatosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $candidato1=new Candidato();
        $candidato1->name="Adrian de la Fuente";
        $candidato1->edad=18;
        $candidato1->curp="JDJDJ848484";
        $candidato1->save();

        $candidato2=new Candidato();
        $candidato2->name="Guadalupe Pérez Sorie";
        $candidato2->edad=15;
        $candidato2->curp="JDJfffDJ848484";
        $candidato2->save();

        $candidato3=new Candidato();
        $candidato3->name="Martha Gallegos Martínez";
        $candidato3->edad=22;
        $candidato3->curp="MARTH848484";
        $candidato3->save();

        $candidato4=new Candidato();
        $candidato4->name="Carlos Martell";
        $candidato4->edad=38;
        $candidato4->curp="JtttttDJDJ848484";
        $candidato4->save();


    }
}
