<?php

use Illuminate\Database\Seeder;
use Tecnologico\Role;
use Tecnologico\User;


class UserTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role_escolares  = Role::where('name', 'escolares')->first();
        $role_se_sec_isc = Role::where('name', 'se_sec_isc')->first();
    	$role_se_sec_inf  = Role::where('name', 'se_sec_inf')->first();
        $role_se_sec_ind = Role::where('name', 'se_sec_mec')->first();
        $role_se_sec_mec  = Role::where('name', 'se_sec_electro')->first();
        $role_se_sec_electro  = Role::where('name', 'se_sec_electri')->first();
        $role_se_sec_electri  = Role::where('name', 'se_sec_electri')->first();

        $esccolares = new User();
    	$esccolares->name = 'Berenice';
    	$esccolares->email = 'bere@itslp.edu.mx';
    	$esccolares->password = bcrypt('123');
    	$esccolares->save();
    	$esccolares->roles()->attach($role_escolares);

        $susana = new User();
    	$susana->name = 'susana';
    	$susana->email = 'susana@itslp.edu.mx';
    	$susana->password = bcrypt('123');
    	$susana->save();
    	$susana->roles()->attach($role_se_sec_isc);
        $susana->roles()->attach($role_se_sec_inf);

        $teresa = new User();
        $teresa->name = 'teresa';
        $teresa->email = 'teresa@itslp.edu.mx';
        $teresa->password = bcrypt('123');
        $teresa->save();
        $teresa->roles()->attach($role_se_sec_mec);

        $martha = new User();
        $martha->name = 'martha';
        $martha->email = 'martha@itslp.edu.mx';
        $martha->password = bcrypt('123');
        $martha->save();
        $martha->roles()->attach($role_se_sec_electro); 
        $martha->roles()->attach($role_se_sec_electri);         

    }
}
