<?php

use Illuminate\Database\Seeder;
use Tecnologico\Role;

class RoleTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role_escolares = new Role();
	    $role_escolares->name = 'escolares';
	    $role_escolares->description = 'Jefe de Servicios Escolares';
	    $role_escolares->save();

	    $role_se_sec_isc = new Role();
	    $role_se_sec_isc->name = 'se_sec_isc';
	    $role_se_sec_isc->description = 'Secretaria de Servicios Escolares de la Carrera Ing. Sistemas Computacionles';
	    $role_se_sec_isc->save();

	    $role_se_sec_inf = new Role();
	    $role_se_sec_inf->name = 'se_sec_inf';
	    $role_se_sec_inf->description = 'Secretaria de Servicios Escolares de la Carrera Ing. Informática';
	    $role_se_sec_inf->save();

	    $role_se_sec_ind = new Role();
	    $role_se_sec_ind->name = 'se_sec_ind';
	    $role_se_sec_ind->description = 'Secretaria de Servicios Escolares de la Carrera Ing. Industrial';
	    $role_se_sec_ind->save();

	    $role_se_sec_mec = new Role();
	    $role_se_sec_mec->name = 'se_sec_mec';
	    $role_se_sec_mec->description = 'Secretaria de Servicios Escolares de la Carrera Ing. Mecánica';
	    $role_se_sec_mec->save();

	   	$role_se_sec_electro = new Role();
	    $role_se_sec_electro->name = 'se_sec_electro';
	    $role_se_sec_electro->description = 'Secretaria de Servicios Escolares de la Carrera Ing. Electrónica';
	    $role_se_sec_electro->save();

	   	$role_se_sec_electri = new Role();
	    $role_se_sec_electri->name = 'se_sec_electro';
	    $role_se_sec_electri->description = 'Secretaria de Servicios Escolares de la Carrera Ing. Electrica';
	    $role_se_sec_electri->save();


    }
}
