<?php

use Illuminate\Database\Seeder;
use Tecnologico\Carrera;

class TablaCarrerasSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        $carrera1=new Carrera();
        $carrera1->num_carrera_int=10;
        $carrera1->nom_corto_tx="ISC";
        $carrera1->nom_largo_tx="ING. EN SISTEMAS COMPUTACIONELASE";
        $carrera1->save();

     	$carrera2=new Carrera();
        $carrera2->num_carrera_int=12;
        $carrera2->nom_corto_tx="IND";
        $carrera2->nom_largo_tx="ING. INDUSTRIAL";
        $carrera2->save();

     	$carrera3=new Carrera();
        $carrera3->num_carrera_int=13;
        $carrera3->nom_corto_tx="MEC";
        $carrera3->nom_largo_tx="ING. EN MECÁNICA";
        $carrera3->save();


     	$carrera4=new Carrera();
        $carrera4->num_carrera_int=14;
        $carrera4->nom_corto_tx="ELECTRO";
        $carrera4->nom_largo_tx="ING. EN ELECTRONICA";
        $carrera4->save();


     	$carrera5=new Carrera();
        $carrera5->num_carrera_int=15;
        $carrera5->nom_corto_tx="ELECTRI";
        $carrera5->nom_largo_tx="ING. EN ELECTRICA";
        $carrera5->save();
           
        $carrera6=new Carrera();
        $carrera6->num_carrera_int=16;
        $carrera6->nom_corto_tx="INF";
        $carrera6->nom_largo_tx="ING. EN INFORMÁTICA";
        $carrera6->save();
            
    }
}
