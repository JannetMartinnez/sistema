@extends('layouts.app')
@section('pageTitle', 'Aspirantes')

@section('content')
<div class="container principal">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Datos de los Aspirantes...</div>

                <div class="panel-body">
                    <form>
                      <label class="col-xs-12 col-sm-2 col-md-2 col-lg-2 control-label" for="carrera">&nbsp;Seleccione carrera:</label>
                    <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 ">
                    <select id="carrera">
                        @foreach ($carreras as $carrera)
                            <option value="{{ $carrera->num_carrera_int }}">{{ $carrera->nom_corto_tx }}- {{ $carrera->nom_largo_tx }}</option>
                        @endforeach
                     </select>
                    </div>
                  </div>
                     <div class="table-responsive">
                       <table class="table table-bordered table-striped">
                        <thead>
                          <tr>
                            <th>Nombre</th>
                            <th>Edad</th>
                            <th>Curp</th>
                            <th>Documentos</th>
                          </tr>
                        </thead>
                        <tbody>
                          @foreach ($candidatos as $candidato)
                            <tr>
                              <td>{{ $candidato-> name}}</td>
                              <td class="text-center">{{ $candidato->edad }}</td>
                              <td>{{ $candidato->curp }}</td>
                              <td class="text-center">
                                <a href="{{ URL::route('candidatoDocumento')}}"><i class="fa fa-cloud-upload" aria-hidden="true"></i> Documentos</a>
                              </td>
                            </tr>
                        @endforeach
                        </tbody>
                      </table>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection