@extends('layouts.app')
@section('pageTitle', 'Aspirantes')
@section('content')
<div class="container principal">
 <script type="text/javascript">
   function inputfile(elm){
    var str = elm.value;
    var res = str.split("\\");
    elm.parentNode.nextSibling.value = res[res.length-1];
  }
 </script>
<div class="row">
  <div class="col-md-12">
    <div class="panel panel-default">
      <div class="panel-heading">Agregar archivos del aspirante <strong>Adrian de la Fuente</strong></div>
        <div class="panel-body">
          <form method="POST" action="{{URL::route('uno')}}" accept-charset="UTF-8" enctype="multipart/form-data">
             <input type="hidden" name="_token" value="{{ csrf_token() }}">
              <div class="form-group">
              <label class="col-md-2 control-label">Nuevo Archivo</label>
              <div class="col-md-6 form-group">
                <label for="imagen" class="input-group-btn input-file">  </label>
                    <div class="boton btn btn-itslp">
                    <input type="file" name="file" id="imagen">

              </div>
            </div>
 
            <div class="form-group">
              <div class="col-md-8 text-right">
                <button type="submit" class="btn btn-itslp">Enviar</button>
              </div>
            </div>
          </form>


 <div style="clear:both;">

          <br/>
                <h3>Documentos actuales</h3>
                <table border="1">
                  <tr><th>Documento</th><th>Ver</th><th>Eliminar</th></tr>
                  @foreach ($actuales as $k=>$v)
                     <tr>
                       <td>{{$v}}</td>
                       <td>
                       <a href="{{URL::route('dos')}}">ver
                       </a>
                       </td>
                       <td><a href="{{URL::route('tres')}}">Eliminar</a></td>
                     </tr>
                  @endforeach
                </table>
          </div>


        </div>
      </div>
    </div>
  </div>
</div>
 
@endsection