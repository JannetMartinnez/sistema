<?php

namespace Tecnologico;

use Tecnologico\CandidatoDocumento;

use Illuminate\Database\Eloquent\Model;

class Candidato extends Model
{
    //
    public function documentos()
    {
      return $this->belongsToOne('Tecnologico\CandidatoDocumento')->withTimestamps();
    }
}
