<?php

namespace Tecnologico;

use Illuminate\Database\Eloquent\Model;

class Storage extends Model
{
    //
}
