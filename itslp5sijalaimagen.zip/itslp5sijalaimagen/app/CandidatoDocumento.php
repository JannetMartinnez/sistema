<?php

namespace Tecnologico;

use Illuminate\Database\Eloquent\Model;

class CandidatoDocumento extends Model
{
    //
    return $this->belongsToMany('Tecnologico\Candidato')->withTimestamps();
}
