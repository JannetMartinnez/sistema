<?php

namespace Tecnologico\Http\Controllers;

use Tecnologico\CandidatoDocumento;
use Illuminate\Http\Request;
use Illuminate\Http\File;
use Illuminate\Support\Facades\Storage;
class CandidatoDocumentoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $actuales=Storage::files('public');
        
        return view('candidatoDocumento',compact('actuales'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        /*
        //Obtenemos la información del formulario
        $file=$request->file('file');
        //Obtenemos el nombre del archivo
        $nombre=$file->getClientOriginalName();
        //Indicamos que queremos guardar un nuevo archivo en el disco
        Storage::disk('local')->put('pruebas',$file);     
        return redirect('/candidato'); 
        */
        /*Esto si funciona tambien
        if($request->hasFile('file')){
            $request->file('file');
            //return $request->file->path();
            //return $request->file->extension();
            //return $request->file->store('public');

        }
        else{
            return 'No file selectedddd';
        }
        */
        /*
        //Crear un diretorio, resulta boolean
        Storage::makeDirectory('public/make');
        if(Storage::deleteDirectory('public/make') )
            return 'Directory deleted';
         */
        // Convinado con Storage y hasFile, tambien funciono
        /*
         if($request->hasFile('file')){
            $request->file('file');
            return Storage::disk('local')->put('pruebas',$request->file('file'));  
        }
        else{
            return 'No file selectedddd';
        }
        
        */
        //Almacena la imagen con un nombre de archivo y en un subdirectorio
        // Corrio bien
        /*
         if($request->hasFile('file')){
            $request->file('file');
            return $request->file->storeAs('public/pruebas2','bitfumes.jpg');
        }else
        {
            return 'No file selected';
        }
        */
        //Lo mismo pero en public para probarlo con el link
        if($request->hasFile('file')){
            //$request->file('file');
            $filename=$request->file->getClientOriginalName();
            //return $filesize=$request->file->getClientSize();
            $filesize=$request->file->getClientSize();

            $request->file->storeAs('public',$filename);
            //Lista todos los archivo del directorio imagenes
            $actuales=Storage::files('public');
            return view('candidatoDocumento',compact('actuales'));
            //return view('candidatoDoumento',['archActual',$archActual]);
        }else
        {
            return 'No file selected';
        }
        


    }

    /**
     * Display the specified resource.
     *
     * @param  \Tecnologico\CandidatoDocumento  $candidatoDocumento
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //Hay quue poner la link en artisan 
        //php artisan storage:link
        //Creara en resource, storege un link

        //return Storage::url('bitfumes.jpg');
        $url=Storage::url('estsela.jpg');


        return view('verFile',['url'=>$url]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \Tecnologico\CandidatoDocumento  $candidatoDocumento
     * @return \Illuminate\Http\Response
     */
    public function edit(CandidatoDocumento $candidatoDocumento)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Tecnologico\CandidatoDocumento  $candidatoDocumento
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, CandidatoDocumento $candidatoDocumento)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Tecnologico\CandidatoDocumento  $candidatoDocumento
     * @return \Illuminate\Http\Response

    public function destroy(CandidatoDocumento $candidatoDocumento)
    {
        //
        return 'tendre que borrar el documento';
    }
         */

    /**
     * Remove the specified resource from storage.
     *
     * @param  \Tecnologico\CandidatoDocumento  $candidatoDocumento
     * @return \Illuminate\Http\Response
     */
    public function destroy()
    {
        //
        return 'tendre que borrar el documento';
    }
}
